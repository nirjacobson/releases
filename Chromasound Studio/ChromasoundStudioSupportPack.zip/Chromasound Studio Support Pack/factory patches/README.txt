Usage
-----

Open an OPM patch collection file in the OPN Import dialog under Tools. From there you can assign individual patches to different channels in your project.
