Usage
-----

Load the drum ROM (drums.rom) as either your SPCM (Nova) or DPCM (Pro, Prodigy) ROM under Edit > Globals > PCM.

Create an SPCM or DPCM channel. In its settings, load the drum layout file (drums.lay).

The drum ROM contains all the percussion instruments exposed by MIDI channel 10. The layout file maps keys to percussion instruments matching the layout of MIDI channel 10.
